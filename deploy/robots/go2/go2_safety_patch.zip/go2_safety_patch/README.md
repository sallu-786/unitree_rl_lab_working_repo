# Go2 low-level mode safety patch

Goal: the FSM/lowcmd publisher must never run unless the robot has
confirmed it released the factory sport-mode service, mode loss must be
caught while running (not just at startup), and shutdown/signal handling
must not hang or corrupt state. No changes to your FSM logic, gains, or
trajectories.

## Files in this zip

```
include/Safety/ModeGate.h   <- NEW FILE, copy in as-is
include/FSM/FSMState.h      <- REPLACES your existing include/FSM/FSMState.h
main.cpp                    <- REPLACES your existing deploy/robots/go2/main.cpp
```

## Where each one goes

1. **`include/Safety/ModeGate.h`**
   Copy the whole `Safety/` folder into your project's `include/` dir,
   next to your existing `FSM/` folder.

   Three separate mechanisms inside, each fixing a specific bug:

   - **`EnsureLowLevel()`** — startup gate. `CheckMode()` is itself an RPC
     call: if the robot isn't reachable yet it returns a non-zero code and
     leaves `name` empty, which looks identical to "confirmed released."
     This only treats `name.empty()` as success when the return code is
     `0`. On any non-zero code it waits and retries — it never calls
     `ReleaseMode()` against a robot it isn't actually talking to yet.

   - **`StartWatchdog()` / `IsModeOk()`** — ongoing check, new in this
     version. Runs `CheckMode()` on its own background thread every
     second and caches the result in an `std::atomic<bool>`. The FSM's
     per-tick safety check only ever reads that cached atomic — it never
     calls the RPC directly — so a slow or hung network round-trip can
     never stall the 1kHz control loop. Fixes: previously nothing
     detected if sport mode got re-claimed (e.g. someone opens the phone
     app) *while the FSM was already running*.

   - **`RestoreHighLevel()`** — shutdown path, timeout-bounded (default
     2s). **Uses a detached thread + polling, not `std::async`.** An
     earlier draft of this used `std::async(std::launch::async, ...)` and
     checked `future::wait_for()` for the timeout — but a `std::future`
     from `std::async` **blocks in its own destructor** until the task
     finishes, even if you already decided to give up and return. So the
     timeout branch would log "timed out" and then silently hang anyway
     on exactly the case it exists to handle (dead network on shutdown).
     The detached-thread version has no such trap: if `SelectMode()`
     never returns, this function still returns on schedule.

   Also **do not call `RestoreHighLevel()` from inside a POSIX signal
   handler** — it spawns a thread and does RPC/mutex work, none of which
   is async-signal-safe (see `main.cpp` below for why).

   All `MotionSwitcherClient` calls are now behind an internal
   `std::mutex`, since both the watchdog thread and the main/FSM thread
   can call into it.

2. **`include/FSM/FSMState.h`**
   Overwrite your current file. Additions to the constructor's
   `registered_checks` list (same mechanism your existing `isTimeout()`
   check already uses — nothing architecturally new):

   - Hold **Back**, from any state → stops the watchdog, calls the
     timeout-bounded `RestoreHighLevel()`, exits. Change
     `"back.on_pressed"` if Back is already bound elsewhere.
   - A new check that reads `mode_gate->IsModeOk()` every tick. If sport
     mode gets re-claimed mid-run, this forces a transition to `Passive`
     and logs a `critical` once (edge-detected, so it doesn't spam every
     tick while the condition persists).

   Also added: `static std::shared_ptr<ModeGate> mode_gate;` member.

3. **`main.cpp`**
   Overwrite your current file.

   - **Signal handler is now signal-safe.** `on_signal()` only sets
     `std::atomic<bool> g_shutdown_requested` — nothing else. The
     previous version called `RestoreHighLevel()` (RPC + mutex + logging)
     directly inside the handler, which is undefined behavior: if the
     signal arrives while another thread holds a lock that call also
     needs, the process can hang instead of exiting. All actual cleanup
     now happens in the existing `while(true) { sleep(1); }` loop on the
     main thread, which checks the flag once a second.
   - Calls `mode_gate->StartWatchdog()` right after `EnsureLowLevel()`
     succeeds.
   - On shutdown (signal or otherwise), stops the watchdog before calling
     `RestoreHighLevel()`, so the background thread isn't racing the
     `SelectMode()` RPC (the internal mutex would also make this safe,
     but stopping it first is cleaner).
   - Still includes the earlier fix: `init_fsm_state()`'s dead
     `exit(0)` (commented out, so it fell through and kept running after
     detecting another process on the lowcmd channel) is now a real
     `exit(1)`.

## What you do NOT need to touch

`State_Passive.h`, `State_FixStand.h`, `State_RLBase.h/.cpp`,
`CtrlFSM.h`, `BaseState.h`, `FSM.yaml`, `CMakeLists.txt` — all unchanged.
`MotionSwitcherClient` ships inside `unitree_sdk2`, already linked.

## How to verify it worked

```
ModeGate: not connected to robot yet (CheckMode code=...), retrying...   <- normal at startup, may repeat
ModeGate: connected, currently in 'normal', releasing...
ModeGate: low-level mode CONFIRMED
Waiting for connection to robot...
Connected to robot.
FSM: Start Passive
Press [L2 + A] to enter FixStand mode.
...
Hold [Back] at any time to exit and return to high-level mode.
```

To test the new mid-run watchdog: while the FSM is running, trigger
sport mode from the official app or another SDK session. Within ~1s you
should see:

```
ModeGate: sport mode re-claimed control mid-run (code=..., name='...')!
Low-level mode lost mid-run! Forcing Passive.
FSM: Change state from ... to Passive
```

To test signal handling: press Ctrl+C. You should see
`Signal received, restoring high-level mode...` followed by a clean
exit within ~2 seconds even if the robot is unreachable (the timeout
kicks in rather than hanging — this is the part that was actually
broken in an earlier draft of this patch; the detached-thread
implementation in `ModeGate.h` is what makes the 2-second bound real).

If startup instead prints `Aborting: robot still under sport-mode
control.` and exits — that's the gate doing its job with a real,
confirmed answer. Check for another process holding the sport-mode
service, or a dead network interface.

## Operating sequence (unchanged)

1. Run the binary → mode gate auto-releases sport mode (blocks until confirmed) → watchdog starts
2. `Passive` — damping, safe idle
3. `LT + A` → `FixStand` — stand up
4. `Start` → `Velocity` — RL policy walking
5. `LT + A` (from Velocity) → back to `FixStand` — stop walking, hold stance
6. `LT + B` (from FixStand or Velocity) → `Passive` — emergency drop to damping
7. Hold `Back` (any state), Ctrl+C, or sport mode re-claimed mid-run → restore high-level mode, safe stop
