// Copyright (c) 2025, Unitree Robotics Co., Ltd.
// All rights reserved.
#pragma once

#include <unitree/robot/b2/motion_switcher/motion_switcher_client.hpp>
#include <spdlog/spdlog.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>

// Wraps the official MotionSwitcherClient (CheckMode/SelectMode/ReleaseMode).
//
// Three separate concerns, each fixed for a specific bug:
//  1. EnsureLowLevel()   - startup gate. Distinguishes "not connected yet"
//                          from "confirmed released" via the CheckMode
//                          return code, not just the string content.
//  2. StartWatchdog()    - ongoing check. Runs CheckMode() on its OWN
//                          thread so a slow/hung RPC never stalls the
//                          1kHz FSM control loop. The FSM only ever reads
//                          a cached atomic bool.
//  3. RestoreHighLevel() - shutdown path. Bounded by a timeout so a dead
//                          network never hangs process exit forever, and
//                          is NEVER called directly from a signal handler
//                          (see main.cpp) since RPC is not async-signal-safe.
class ModeGate
{
public:
    ModeGate() { client_.Init(); }

    ~ModeGate() { StopWatchdog(); }

    // Blocks until factory sport control is confirmed released.
    bool EnsureLowLevel(int max_tries = 30)
    {
        std::string form, name;
        for (int i = 0; i < max_tries; ++i)
        {
            int32_t ret;
            {
                std::lock_guard<std::mutex> lock(client_mutex_);
                ret = client_.CheckMode(form, name);
            }

            if (ret != 0)
            {
                spdlog::warn("ModeGate: not connected to robot yet (CheckMode code={}), retrying...", ret);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                continue; // do NOT call ReleaseMode — state is unknown
            }

            if (name.empty())
            {
                spdlog::info("ModeGate: low-level mode CONFIRMED");
                mode_ok_ = true;
                return true;
            }

            spdlog::warn("ModeGate: connected, currently in '{}', releasing...", name);
            {
                std::lock_guard<std::mutex> lock(client_mutex_);
                client_.ReleaseMode();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        spdlog::critical("ModeGate: could not confirm low-level mode after {} tries, refusing to start", max_tries);
        return false;
    }

    // Runs CheckMode() periodically on a background thread and caches the
    // result in an atomic. Call once, after EnsureLowLevel() succeeds.
    // The FSM's registered_check reads IsModeOk() — never calls CheckMode
    // directly — so a slow RPC round-trip never blocks the control loop.
    void StartWatchdog(int interval_ms = 1000)
    {
        if (watch_running_) return;
        watch_running_ = true;
        watch_thread_ = std::thread([this, interval_ms]{
            std::string form, name;
            while (watch_running_)
            {
                int32_t ret;
                {
                    std::lock_guard<std::mutex> lock(client_mutex_);
                    ret = client_.CheckMode(form, name);
                }
                bool ok = (ret == 0 && name.empty());
                if (!ok && mode_ok_)
                {
                    spdlog::critical("ModeGate: sport mode re-claimed control mid-run "
                                      "(code={}, name='{}')! Robot may be receiving conflicting commands.",
                                      ret, name);
                }
                mode_ok_ = ok;
                std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
            }
        });
    }

    void StopWatchdog()
    {
        watch_running_ = false;
        if (watch_thread_.joinable()) watch_thread_.join();
    }

    // Signal-safe to call FROM: nowhere unsafe. This still does blocking
    // RPC, so only call it from normal thread context (main loop, FSM
    // thread) — never from inside a POSIX signal handler. Bounded by
    // timeout_ms so a dead network can't hang process exit forever.
    //
    // NOTE: this deliberately does NOT use std::async. A std::future
    // returned by std::async(launch::async, ...) BLOCKS IN ITS OWN
    // DESTRUCTOR until the task finishes — so even on the "timeout"
    // branch, returning out of this function would silently block on
    // that destructor anyway, defeating the entire point of the
    // timeout. A detached std::thread + polling on an atomic has no
    // such trap: if SelectMode() never returns, this function still
    // returns on schedule and the leaked thread just runs out its RPC
    // in the background until the process exits.
    bool RestoreHighLevel(int timeout_ms = 2000)
    {
        auto result = std::make_shared<std::atomic<int32_t>>(-1);
        auto done   = std::make_shared<std::atomic<bool>>(false);

        std::thread([this, result, done]{
            int32_t ret;
            {
                std::lock_guard<std::mutex> lock(client_mutex_);
                ret = client_.SelectMode("normal");
            }
            *result = ret;
            *done = true;
        }).detach();

        auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);
        while (!*done)
        {
            if (std::chrono::steady_clock::now() >= deadline)
            {
                spdlog::error("ModeGate: RestoreHighLevel timed out after {} ms — "
                              "robot may still be in low-level mode, verify manually.", timeout_ms);
                mode_ok_ = false;
                return false; // detached thread keeps running; harmless, we're exiting anyway
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }

        spdlog::info("ModeGate: restore high-level -> code={}", result->load());
        mode_ok_ = false;
        return result->load() == 0;
    }

    // Cheap, non-blocking. Safe to call every FSM tick.
    bool IsModeOk() const { return mode_ok_; }

private:
    unitree::robot::b2::MotionSwitcherClient client_;
    std::mutex client_mutex_;
    std::atomic<bool> mode_ok_{false};
    std::atomic<bool> watch_running_{false};
    std::thread watch_thread_;
};
