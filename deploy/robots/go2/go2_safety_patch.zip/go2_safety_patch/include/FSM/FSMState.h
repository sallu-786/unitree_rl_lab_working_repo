#pragma once

#include "Types.h"
#include "param.h"
#include "FSM/BaseState.h"
#include "isaaclab/devices/keyboard/keyboard.h"
#include "unitree_joystick_dsl.hpp"
#include "Safety/ModeGate.h"   // ADDED

class FSMState : public BaseState
{
public:
    FSMState(int state, std::string state_string) 
    : BaseState(state, state_string) 
    {
        spdlog::info("Initializing State_{} ...", state_string);

        auto transitions = param::config["FSM"][state_string]["transitions"];

        if(transitions)
        {
            auto transition_map = transitions.as<std::map<std::string, std::string>>();

            for(auto it = transition_map.begin(); it != transition_map.end(); ++it)
            {
                std::string target_fsm = it->first;
                if(!FSMStringMap.right.count(target_fsm))
                {
                    spdlog::warn("FSM State_'{}' not found in FSMStringMap!", target_fsm);
                    continue;
                }

                int fsm_id = FSMStringMap.right.at(target_fsm);

                std::string condition = it->second;
                unitree::common::dsl::Parser p(condition);
                auto ast = p.Parse();
                auto func = unitree::common::dsl::Compile(*ast);
                registered_checks.emplace_back(
                    std::make_pair(
                        [func]()->bool{ return func(FSMState::lowstate->joystick); },
                        fsm_id
                    )
                );
            }
        }

        // register for all states
        registered_checks.emplace_back(
            std::make_pair(
                []()->bool{ return lowstate->isTimeout(); },
                FSMStringMap.right.at("Passive")
            )
        );

        // ADDED: universal safety exit — hold Back, from ANY state, to
        // restore high-level (sport) mode and terminate the process.
        // Change "back.on_pressed" below if Back is already bound elsewhere,
        // e.g. to "LT(2s) + back" for a deliberate hold-to-confirm.
        // RestoreHighLevel() is timeout-bounded (see ModeGate.h) so this
        // can't hang forever even if the robot is unreachable.
        registered_checks.emplace_back(
            std::make_pair(
                []()->bool {
                    static unitree::common::dsl::Parser p("back.on_pressed");
                    static auto ast = p.Parse();
                    static auto func = unitree::common::dsl::Compile(*ast);
                    if (func(FSMState::lowstate->joystick))
                    {
                        spdlog::warn("Exit requested: restoring high-level mode");
                        if (mode_gate) mode_gate->StopWatchdog();
                        if (mode_gate) mode_gate->RestoreHighLevel();
                        std::exit(0);
                    }
                    return false;
                },
                FSMStringMap.right.at("Passive")
            )
        );

        // ADDED: ongoing check that sport mode hasn't been re-claimed
        // mid-run (e.g. someone opens the phone app while the FSM is
        // driving the robot). Reads a cached atomic set by ModeGate's
        // background watchdog thread — never calls the RPC directly here,
        // so this is safe to run every tick without stalling the 1kHz
        // control loop. Edge-detected logging so it warns once, not every
        // tick, while the condition persists.
        registered_checks.emplace_back(
            std::make_pair(
                []()->bool {
                    static bool warned = false;
                    if (mode_gate && !mode_gate->IsModeOk())
                    {
                        if (!warned)
                        {
                            spdlog::critical("Low-level mode lost mid-run! Forcing Passive.");
                            warned = true;
                        }
                        return true;
                    }
                    warned = false;
                    return false;
                },
                FSMStringMap.right.at("Passive")
            )
        );
    }

    void pre_run()
    {
        lowstate->update();
        if(keyboard) keyboard->update();
    }

    void post_run()
    {
        lowcmd->unlockAndPublish();
    }

    static std::unique_ptr<LowCmd_t> lowcmd;
    static std::shared_ptr<LowState_t> lowstate;
    static std::shared_ptr<Keyboard> keyboard;
    static std::shared_ptr<ModeGate> mode_gate;   // ADDED
};
