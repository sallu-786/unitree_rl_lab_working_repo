#include "FSM/CtrlFSM.h"
#include "FSM/State_Passive.h"
#include "FSM/State_FixStand.h"
#include "FSM/State_RLBase.h"
#include "Safety/ModeGate.h"     // ADDED
#include <csignal>                // ADDED
#include <atomic>                 // ADDED

std::unique_ptr<LowCmd_t> FSMState::lowcmd = nullptr;
std::shared_ptr<LowState_t> FSMState::lowstate = nullptr;
std::shared_ptr<Keyboard> FSMState::keyboard = nullptr;
std::shared_ptr<ModeGate> FSMState::mode_gate = nullptr;   // ADDED

void init_fsm_state()
{
    auto lowcmd_sub = std::make_shared<unitree::robot::go2::subscription::LowCmd>();
    usleep(0.2 * 1e6);
    if(!lowcmd_sub->isTimeout())
    {
        spdlog::critical("The other process is using the lowcmd channel, please close it first.");
        unitree::robot::go2::shutdown();
        exit(1); // CHANGED: was a dead exit(0) behind a comment; now actually stops
    }
    FSMState::lowcmd = std::make_unique<LowCmd_t>();
    FSMState::lowstate = std::make_shared<LowState_t>();
    spdlog::info("Waiting for connection to robot...");
    FSMState::lowstate->wait_for_connection();
    spdlog::info("Connected to robot.");
}

// ADDED: signal handlers must be async-signal-safe — no RPC, no mutexes,
// no logging inside them. This ONLY sets an atomic flag; the actual
// cleanup (StopWatchdog + timeout-bounded RestoreHighLevel) runs on the
// main thread below, which is always alive and idle in the sleep(1) loop.
std::atomic<bool> g_shutdown_requested{false};
void on_signal(int)
{
    g_shutdown_requested = true;
}

int main(int argc, char** argv)
{
    auto vm = param::helper(argc, argv);

    std::cout << " --- Unitree Robotics --- \n";
    std::cout << "     Go2 Controller \n";

    unitree::robot::ChannelFactory::Instance()->Init(0, vm["network"].as<std::string>());

    std::signal(SIGINT, on_signal);    // ADDED
    std::signal(SIGTERM, on_signal);   // ADDED

    // ADDED: force low-level mode before anything else runs. If the sport
    // service won't release, we exit here — lowcmd/lowstate are never
    // even constructed, so nothing can be published to the motors.
    FSMState::mode_gate = std::make_shared<ModeGate>();
    if (!FSMState::mode_gate->EnsureLowLevel())
    {
        spdlog::critical("Aborting: robot still under sport-mode control.");
        return 1;
    }
    // ADDED: ongoing check that sport mode isn't re-claimed mid-run.
    // Runs on its own thread; FSMState only ever reads the cached result.
    FSMState::mode_gate->StartWatchdog();

    init_fsm_state();

    auto fsm = std::make_unique<CtrlFSM>(param::config["FSM"]);
    fsm->start();

    std::cout << "Press [L2 + A] to enter FixStand mode.\n";
    std::cout << "And then press [Start] to start controlling the robot.\n";
    std::cout << "Hold [Back] at any time to exit and return to high-level mode.\n"; // ADDED

    while (true)
    {
        // ADDED: real Ctrl+C/SIGTERM cleanup happens here, not in the
        // signal handler. StopWatchdog before RestoreHighLevel so the
        // watchdog thread isn't calling CheckMode concurrently with the
        // SelectMode RPC (ModeGate's internal mutex would also block this
        // safely, but it's cleaner to just stop it first).
        if (g_shutdown_requested)
        {
            spdlog::warn("Signal received, restoring high-level mode...");
            if (FSMState::mode_gate)
            {
                FSMState::mode_gate->StopWatchdog();
                FSMState::mode_gate->RestoreHighLevel();
            }
            std::exit(0);
        }
        sleep(1);
    }
    
    return 0;
}
